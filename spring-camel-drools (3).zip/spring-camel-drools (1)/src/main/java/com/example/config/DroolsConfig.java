package com.example.config;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DroolsConfig {

    private static final String RULES_PATH = "rules/";
    private KieContainer kieContainer;

    @Bean
    public KieContainer kieContainer() {
        if (kieContainer != null) {
            return kieContainer;
        }

        KieServices kieServices = KieServices.Factory.get();
        KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
        
        // Load rule files
        kieFileSystem.write(ResourceFactory.newClassPathResource(RULES_PATH + "OrderProcessingRules.drl"));
        kieFileSystem.write(ResourceFactory.newClassPathResource(RULES_PATH + "DiscountRules.drl"));
        kieFileSystem.write(ResourceFactory.newClassPathResource(RULES_PATH + "CustomerValidationRules.drl"));
        
        KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        
        // Check for compilation errors
        if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
            System.err.println("Drools compilation errors:");
            kieBuilder.getResults().getMessages().forEach(System.err::println);
            throw new RuntimeException("Drools compilation failed");
        }
        
        KieModule kieModule = kieBuilder.getKieModule();
        kieContainer = kieServices.newKieContainer(kieModule.getReleaseId());
        
        System.out.println("KieContainer initialized successfully");
        return kieContainer;
    }

    @Bean(name = "orderProcessingSession")
    public KieSession orderProcessingSession() {
        KieSession session = kieContainer().newKieSession();
        if (session == null) {
            throw new RuntimeException("Failed to create KieSession");
        }
        System.out.println("OrderProcessingSession created successfully");
        return session;
    }

    @Bean(name = "customerValidationSession")
    public KieSession customerValidationSession() {
        KieSession session = kieContainer().newKieSession();
        if (session == null) {
            throw new RuntimeException("Failed to create KieSession");
        }
        System.out.println("CustomerValidationSession created successfully");
        return session;
    }
}
