package com.example.controller;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.service.OrderProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
public class TestController {

    @Autowired
    private OrderProcessingService orderProcessingService;

    @GetMapping("/simple")
    public ResponseEntity<Map<String, Object>> testSimpleOrder() {
        try {
            // Create a simple test order
            OrderItem item = new OrderItem("TEST001", "Test Product", 1, new BigDecimal("100.00"), "Test");
            Order order = new Order("ORDER001", "CUSTOMER001", Arrays.asList(item));
            
            // Create a test customer
            Customer customer = new Customer("CUSTOMER001", "Test Customer", "test@example.com", "REGULAR");
            
            // Process the order
            Order processedOrder = orderProcessingService.processOrder(order, customer);
            Customer validatedCustomer = orderProcessingService.validateCustomer(customer);
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("order", processedOrder);
            response.put("customer", validatedCustomer);
            response.put("message", "Order processed successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @PostMapping("/full-order")
    public ResponseEntity<Map<String, Object>> testFullOrder(@RequestBody Map<String, Object> request) {
        try {
            // This endpoint can be used to test the same logic as Camel route
            // but through Spring Boot REST controller
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Full order test endpoint working");
            response.put("input", request);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("message", "Application is running");
        return ResponseEntity.ok(response);
    }
}
