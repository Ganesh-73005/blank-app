package com.example.controller;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.route.OrderProcessingRoute;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Arrays;

@RestController
@RequestMapping("/api")
public class OrderController {

    @Autowired
    private ProducerTemplate producerTemplate;

    @PostMapping("/orders/process")
    public ResponseEntity<?> processOrder(@RequestBody OrderProcessingRoute.OrderRequest request) {
        try {
            OrderProcessingRoute.OrderResponse response = producerTemplate.requestBody(
                "direct:processOrder", 
                request, 
                OrderProcessingRoute.OrderResponse.class
            );
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error processing order: " + e.getMessage());
        }
    }

    @GetMapping("/orders/sample")
    public ResponseEntity<OrderProcessingRoute.OrderRequest> getSampleOrder() {
        // Create sample order items
        OrderItem item1 = new OrderItem("PROD001", "Laptop", 1, new BigDecimal("999.99"), "Electronics");
        OrderItem item2 = new OrderItem("PROD002", "Mouse", 2, new BigDecimal("25.50"), "Accessories");

        // Create sample order
        Order order = new Order("ORD001", "CUST001", Arrays.asList(item1, item2));

        // Create sample customer
        Customer customer = new Customer("CUST001", "John Doe", "john.doe@example.com", "PREMIUM");
        customer.setLoyaltyPoints(1500);

        // Create request
        OrderProcessingRoute.OrderRequest request = new OrderProcessingRoute.OrderRequest();
        request.setOrder(order);
        request.setCustomer(customer);

        return ResponseEntity.ok(request);
    }
}
