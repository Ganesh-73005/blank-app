package com.example.route;

import com.example.service.OrderProcessingService;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SimpleOrderRoute extends RouteBuilder {

    @Autowired
    private OrderProcessingService orderProcessingService;

    @Override
    public void configure() throws Exception {
        
        // Global exception handling - MUST be first
        onException(Exception.class)
            .handled(true)
            .log("Error in route: ${exception.message}")
            .setBody(simple("{\"error\": \"Processing failed\", \"message\": \"${exception.message}\"}"))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Configure REST component to use servlet with auto-configuration
        restConfiguration()
            .component("servlet")
            .bindingMode("json")
            .dataFormatProperty("prettyPrint", "true")
            .jsonDataFormat("jackson");

        // Simple REST endpoints
        rest("/api/simple")
            .get("/test")
                .produces("application/json")
                .to("direct:simpleTest")
            .post("/order")
                .consumes("application/json")
                .produces("application/json")
                .to("direct:processSimpleOrder");

        // Simple test route
        from("direct:simpleTest")
            .routeId("simpleTestRoute")
            .log("Simple test endpoint called")
            .setBody(constant("{\"status\": \"success\", \"message\": \"Camel route is working!\", \"timestamp\": \"${date:now:yyyy-MM-dd'T'HH:mm:ss}\"}"))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Simple order processing route
        from("direct:processSimpleOrder")
            .routeId("simpleOrderRoute")
            .log("Processing simple order: ${body}")
            .process(exchange -> {
                try {
                    String inputBody = exchange.getIn().getBody(String.class);
                    String response = "{\"status\": \"success\", \"message\": \"Order received and processed via Camel\", \"timestamp\": \"" + 
                                    java.time.LocalDateTime.now() + "\", \"input\": " + inputBody + "}";
                    exchange.getIn().setBody(response);
                    exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
                } catch (Exception e) {
                    throw new RuntimeException("Failed to process order", e);
                }
            })
            .log("Simple order processed: ${body}");
    }
}
