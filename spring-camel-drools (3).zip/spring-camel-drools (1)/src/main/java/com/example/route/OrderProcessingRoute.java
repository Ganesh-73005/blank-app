package com.example.route;

import com.example.model.Customer;
import com.example.model.Order;
import com.example.service.OrderProcessingService;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderProcessingRoute extends RouteBuilder {

    @Autowired
    private OrderProcessingService orderProcessingService;

    @Override
    public void configure() throws Exception {
    
    // Error handling route - MUST be defined first
    onException(Exception.class)
        .handled(true)
        .log("Error processing order: ${exception.message}")
        .process(exchange -> {
            Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
            OrderResponse errorResponse = new OrderResponse();
            errorResponse.setStatus("ERROR");
            errorResponse.setMessage("Order processing failed: " + exception.getMessage());
            exchange.getIn().setBody(errorResponse);
        })
        .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

    // Configure REST component to use servlet with auto-configuration
    restConfiguration()
        .component("servlet")
        .bindingMode("auto")
        .dataFormatProperty("prettyPrint", "true")
        .jsonDataFormat("jackson");

    // REST endpoint for order processing
    rest("/api/orders")
        .post("/process")
            .consumes("application/json")
            .produces("application/json")
            .type(OrderRequest.class)
            .outType(OrderResponse.class)
            .to("direct:processOrder");

    // Main order processing route
    from("direct:processOrder")
        .routeId("orderProcessingRoute")
        .log("Received order processing request: ${body}")
        .process(exchange -> {
            try {
                OrderRequest request = exchange.getIn().getBody(OrderRequest.class);
                Order order = request.getOrder();
                Customer customer = request.getCustomer();
                
                // Validate customer first
                Customer validatedCustomer = orderProcessingService.validateCustomer(customer);
                
                // Process order with business rules
                Order processedOrder = orderProcessingService.processOrder(order, validatedCustomer);
                
                // Create response
                OrderResponse response = new OrderResponse();
                response.setOrder(processedOrder);
                response.setCustomer(validatedCustomer);
                response.setStatus("SUCCESS");
                response.setMessage("Order processed successfully via Camel and Drools");
                
                exchange.getIn().setBody(response);
            } catch (Exception e) {
                log.error("Error in order processing", e);
                throw e;
            }
        })
        .log("Order processing completed successfully");

    // File-based order processing route
    from("file:input/orders?noop=true")
        .routeId("fileOrderProcessingRoute")
        .log("Processing order file: ${header.CamelFileName}")
        .unmarshal().json(JsonLibrary.Jackson, OrderRequest.class)
        .process(exchange -> {
            try {
                OrderRequest request = exchange.getIn().getBody(OrderRequest.class);
                Order order = request.getOrder();
                Customer customer = request.getCustomer();
                
                // Validate customer first
                Customer validatedCustomer = orderProcessingService.validateCustomer(customer);
                
                // Process order with business rules
                Order processedOrder = orderProcessingService.processOrder(order, validatedCustomer);
                
                // Create response
                OrderResponse response = new OrderResponse();
                response.setOrder(processedOrder);
                response.setCustomer(validatedCustomer);
                response.setStatus("SUCCESS");
                response.setMessage("File order processed successfully via Camel and Drools");
                
                exchange.getIn().setBody(response);
            } catch (Exception e) {
                log.error("Error in file order processing", e);
                throw e;
            }
        })
        .marshal().json(JsonLibrary.Jackson)
        .to("file:output/processed-orders")
        .log("Order file processed and saved to output directory");
}

    // Inner classes for request/response with proper Jackson annotations
    public static class OrderRequest {
        private Order order;
        private Customer customer;

        public OrderRequest() {}

        public Order getOrder() { return order; }
        public void setOrder(Order order) { this.order = order; }
        public Customer getCustomer() { return customer; }
        public void setCustomer(Customer customer) { this.customer = customer; }

        @Override
        public String toString() {
            return "OrderRequest{" +
                    "order=" + order +
                    ", customer=" + customer +
                    '}';
        }
    }

    public static class OrderResponse {
        private Order order;
        private Customer customer;
        private String status;
        private String message;

        public OrderResponse() {}

        public Order getOrder() { return order; }
        public void setOrder(Order order) { this.order = order; }
        public Customer getCustomer() { return customer; }
        public void setCustomer(Customer customer) { this.customer = customer; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }

        @Override
        public String toString() {
            return "OrderResponse{" +
                    "status='" + status + '\'' +
                    ", message='" + message + '\'' +
                    ", order=" + order +
                    ", customer=" + customer +
                    '}';
        }
    }
}
