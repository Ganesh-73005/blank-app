package com.example.service;

import com.example.model.Customer;
import com.example.model.Order;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class OrderProcessingService {

    @Autowired
    private KieContainer kieContainer;

    public Order processOrder(Order order, Customer customer) {
        KieSession kieSession = null;
        try {
            // Ensure order is properly initialized
            initializeOrder(order);
            
            // Create a new session for this processing
            kieSession = kieContainer.newKieSession();
            
            // Insert facts into the session
            kieSession.insert(order);
            kieSession.insert(customer);
            
            // Fire all rules
            int rulesFired = kieSession.fireAllRules();
            System.out.println("Rules fired: " + rulesFired);
            
            return order;
        } catch (Exception e) {
            System.err.println("Error processing order: " + e.getMessage());
            throw new RuntimeException("Order processing failed", e);
        } finally {
            if (kieSession != null) {
                kieSession.dispose();
            }
        }
    }

    public Customer validateCustomer(Customer customer) {
        KieSession kieSession = null;
        try {
            // Create a new session for this validation
            kieSession = kieContainer.newKieSession();
            kieSession.insert(customer);
            kieSession.fireAllRules();
            return customer;
        } catch (Exception e) {
            System.err.println("Error validating customer: " + e.getMessage());
            throw new RuntimeException("Customer validation failed", e);
        } finally {
            if (kieSession != null) {
                kieSession.dispose();
            }
        }
    }

    private void initializeOrder(Order order) {
        // Ensure all required fields are initialized
        if (order.getDiscountAmount() == null) {
            order.setDiscountAmount(BigDecimal.ZERO);
        }
        if (order.getStatus() == null) {
            order.setStatus("PENDING");
        }
        if (order.getPriority() == null) {
            // Priority will be set by rules, but we can leave it null initially
        }
        
        System.out.println("Order initialized: " + order.getOrderId() + 
                          ", discountAmount: " + order.getDiscountAmount() + 
                          ", status: " + order.getStatus());
    }
}
