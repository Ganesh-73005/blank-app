import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"
import Link from "next/link"

const faqCategories = [
  {
    category: "Getting Started",
    questions: [
      {
        question: "How do I create an account?",
        answer:
          "You can create an account by clicking the 'Get Started' button on our homepage. Fill out the registration form with your email and password, and you'll receive a confirmation email to activate your account.",
      },
      {
        question: "Is there a free trial available?",
        answer:
          "Yes! We offer a 14-day free trial for all our plans. You can explore all features without providing a credit card. The trial automatically expires after 14 days unless you choose to subscribe.",
      },
      {
        question: "What browsers are supported?",
        answer:
          "Our platform supports all modern browsers including Chrome, Firefox, Safari, and Edge. We recommend using the latest version of your preferred browser for the best experience.",
      },
    ],
  },
  {
    category: "Features & Functionality",
    questions: [
      {
        question: "What is navigation testing?",
        answer:
          "Navigation testing involves analyzing how users move through your website, identifying potential issues with menu structures, link placements, and overall user flow. Our tools provide comprehensive insights into navigation patterns and user behavior.",
      },
      {
        question: "Can I test mobile navigation?",
        answer:
          "Our platform includes specialized mobile navigation testing tools that analyze touch interactions, responsive menu behavior, and mobile-specific navigation patterns.",
      },
      {
        question: "How accurate are the analytics?",
        answer:
          "Our analytics are highly accurate, using advanced tracking methods and AI-powered analysis. We provide real-time data with 99.9% accuracy for most metrics, including page views, navigation paths, and user interactions.",
      },
    ],
  },
  {
    category: "Billing & Pricing",
    questions: [
      {
        question: "How does billing work?",
        answer:
          "We bill monthly or annually depending on your chosen plan. All charges are processed automatically on your billing date. You'll receive an invoice via email for each payment.",
      },
      {
        question: "Can I change my plan?",
        answer:
          "Yes, you can upgrade or downgrade your plan at any time from your account settings. Plan changes take effect immediately, and billing is prorated accordingly.",
      },
      {
        question: "What payment methods do you accept?",
        answer:
          "We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers for enterprise customers. All payments are processed securely through our payment partners.",
      },
      {
        question: "Do you offer refunds?",
        answer:
          "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied with our service, contact our support team within 30 days of your purchase for a full refund.",
      },
    ],
  },
  {
    category: "Technical Support",
    questions: [
      {
        question: "How can I contact support?",
        answer:
          "You can reach our support team through multiple channels: email (support@navtest.com), live chat (available 24/7), or phone during business hours. Enterprise customers have access to priority support.",
      },
      {
        question: "What are your support hours?",
        answer:
          "Our email and chat support are available 24/7. Phone support is available Monday-Friday, 9 AM to 6 PM PST. Enterprise customers have access to 24/7 phone support.",
      },
      {
        question: "Do you provide training?",
        answer:
          "Yes! We offer comprehensive onboarding for all new users, including video tutorials, documentation, and live training sessions. Enterprise customers receive personalized training sessions.",
      },
    ],
  },
  {
    category: "Security & Privacy",
    questions: [
      {
        question: "How secure is my data?",
        answer:
          "We take security seriously. All data is encrypted in transit and at rest using industry-standard encryption. We're SOC 2 compliant and undergo regular security audits.",
      },
      {
        question: "Do you share my data with third parties?",
        answer:
          "No, we never sell or share your data with third parties. Your navigation data and analytics remain completely private and are only accessible to you and your authorized team members.",
      },
      {
        question: "Where is my data stored?",
        answer:
          "Your data is stored in secure, enterprise-grade data centers with multiple redundancies. We use cloud infrastructure providers that meet the highest security and compliance standards.",
      },
    ],
  },
]

export default function FAQPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>FAQ</span>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about our navigation testing platform. Can't find what you're looking for?
            Contact our support team.
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input placeholder="Search FAQ..." className="pl-10" />
          </div>
        </div>

        {/* FAQ Categories */}
        <div className="space-y-8">
          {faqCategories.map((category, categoryIndex) => (
            <Card key={categoryIndex}>
              <CardHeader>
                <CardTitle className="text-xl">{category.category}</CardTitle>
                <CardDescription>Common questions about {category.category.toLowerCase()}</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {category.questions.map((faq, questionIndex) => (
                    <AccordionItem key={questionIndex} value={`${categoryIndex}-${questionIndex}`}>
                      <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                      <AccordionContent className="text-gray-600">{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Support */}
        <section className="mt-12 text-center bg-blue-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-gray-600 mb-6">Our support team is here to help you get the most out of our platform</p>
          <div className="flex gap-4 justify-center">
            <Button asChild>
              <Link href="/contact">Contact Support</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/support">Visit Help Center</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
