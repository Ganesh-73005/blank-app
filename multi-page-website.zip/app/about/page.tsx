import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Target, Award, Heart } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>About</span>
        </nav>

        <h1 className="text-4xl font-bold mb-8">About Our Company</h1>

        <div className="prose max-w-none mb-12">
          <p className="text-lg text-gray-600 mb-6">
            We are a leading technology company dedicated to creating innovative solutions that help businesses navigate
            the digital landscape. Our mission is to provide cutting-edge tools and services that empower organizations
            to achieve their goals.
          </p>

          <p className="text-lg text-gray-600 mb-8">
            Founded in 2020, we have grown from a small startup to a trusted partner for companies worldwide. Our team
            of experts combines technical expertise with creative thinking to deliver exceptional results.
          </p>
        </div>

        {/* Values Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-8">Our Values</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <Users className="h-8 w-8 text-blue-600 mb-2" />
                <CardTitle>Collaboration</CardTitle>
                <CardDescription>We believe in the power of teamwork and open communication</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <Target className="h-8 w-8 text-green-600 mb-2" />
                <CardTitle>Innovation</CardTitle>
                <CardDescription>Constantly pushing boundaries to create better solutions</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <Award className="h-8 w-8 text-purple-600 mb-2" />
                <CardTitle>Excellence</CardTitle>
                <CardDescription>Committed to delivering the highest quality in everything we do</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <Heart className="h-8 w-8 text-red-600 mb-2" />
                <CardTitle>Integrity</CardTitle>
                <CardDescription>Building trust through honest and transparent relationships</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-8">Meet Our Team</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "Sarah Johnson", role: "CEO & Founder", image: "/placeholder.svg?height=200&width=200" },
              { name: "Michael Chen", role: "CTO", image: "/placeholder.svg?height=200&width=200" },
              { name: "Emily Rodriguez", role: "Head of Design", image: "/placeholder.svg?height=200&width=200" },
            ].map((member, index) => (
              <Card key={index}>
                <CardContent className="pt-6 text-center">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="font-semibold text-lg">{member.name}</h3>
                  <p className="text-gray-600">{member.role}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center bg-blue-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Ready to Work Together?</h2>
          <p className="text-gray-600 mb-6">Let's discuss how we can help your business grow and succeed.</p>
          <div className="flex gap-4 justify-center">
            <Button asChild>
              <Link href="/contact">Contact Us</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/services">Our Services</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
