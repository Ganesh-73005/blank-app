import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, ShoppingCart, Heart, Share2, Check } from "lucide-react"
import Link from "next/link"

// Mock product data
const getProduct = (id: string) => {
  const products = {
    "1": {
      name: "Web Navigator Pro",
      price: "$99",
      originalPrice: "$129",
      rating: 4.8,
      reviews: 124,
      category: "Software",
      image: "/placeholder.svg?height=400&width=600",
      description:
        "Advanced web navigation tool with AI-powered features for comprehensive site analysis and user experience optimization.",
      features: [
        "AI-powered navigation analysis",
        "Real-time performance monitoring",
        "Cross-browser compatibility testing",
        "Advanced reporting dashboard",
        "API integration support",
        "24/7 customer support",
      ],
      specifications: {
        Platform: "Web-based",
        Compatibility: "All modern browsers",
        API: "REST API included",
        Support: "24/7 email and chat",
        Updates: "Automatic updates",
        License: "Commercial license",
      },
    },
  }
  return products[id as keyof typeof products] || products["1"]
}

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = getProduct(params.id)

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <Link href="/products" className="hover:text-blue-600">
            Products
          </Link>
          <span className="mx-2">/</span>
          <span>{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12 mb-12">
          {/* Product Image */}
          <div>
            <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full rounded-lg shadow-lg" />
          </div>

          {/* Product Info */}
          <div>
            <Badge className="mb-4">{product.category}</Badge>
            <h1 className="text-3xl font-bold mb-4">{product.name}</h1>

            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center">
                <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                <span className="ml-1 font-medium">{product.rating}</span>
              </div>
              <span className="text-gray-500">({product.reviews} reviews)</span>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <span className="text-3xl font-bold text-blue-600">{product.price}</span>
              <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
              <Badge variant="secondary">23% OFF</Badge>
            </div>

            <p className="text-gray-600 mb-8">{product.description}</p>

            <div className="flex gap-4 mb-8">
              <Button size="lg" className="flex-1">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Add to Cart
              </Button>
              <Button size="lg" variant="outline">
                <Heart className="h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>

            {/* Key Features */}
            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="h-4 w-4 text-green-600 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Product Details Tabs */}
        <Tabs defaultValue="description" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="support">Support</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4">Product Description</h3>
                <p className="text-gray-600 mb-4">
                  {product.name} is a comprehensive web navigation solution designed for modern businesses. Our advanced
                  AI-powered technology provides deep insights into user behavior and site performance.
                </p>
                <p className="text-gray-600 mb-4">
                  With real-time monitoring and cross-browser compatibility testing, you can ensure your website
                  provides an optimal experience for all users. The intuitive dashboard makes it easy to track key
                  metrics and identify areas for improvement.
                </p>
                <p className="text-gray-600">
                  Perfect for web developers, UX designers, and digital marketing teams who need reliable navigation
                  analysis tools to optimize their websites and improve user engagement.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4">Technical Specifications</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b">
                      <span className="font-medium">{key}:</span>
                      <span className="text-gray-600">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map((review) => (
                    <div key={review} className="border-b pb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                        <span className="font-medium">John Doe</span>
                        <span className="text-sm text-gray-500">2 days ago</span>
                      </div>
                      <p className="text-gray-600">
                        Excellent product! Really helped improve our website's navigation and user experience.
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4">Support & Documentation</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Getting Started</h4>
                    <p className="text-gray-600">
                      Complete setup guide and tutorials to get you up and running quickly.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">API Documentation</h4>
                    <p className="text-gray-600">
                      Comprehensive API reference for developers and technical integrations.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">24/7 Support</h4>
                    <p className="text-gray-600">Round-the-clock customer support via email and live chat.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        <section>
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[2, 3, 4].map((id) => (
              <Card key={id} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <img
                    src="/placeholder.svg?height=150&width=250"
                    alt="Related Product"
                    className="w-full h-32 object-cover rounded mb-4"
                  />
                  <h3 className="font-semibold mb-2">Related Product {id}</h3>
                  <p className="text-gray-600 text-sm mb-4">Another great navigation tool for your toolkit.</p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/products/${id}`}>View Details</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
