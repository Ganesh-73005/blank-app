import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart, Eye } from "lucide-react"
import Link from "next/link"

const products = [
  {
    id: 1,
    name: "Web Navigator Pro",
    price: "$99",
    rating: 4.8,
    reviews: 124,
    category: "Software",
    image: "/placeholder.svg?height=200&width=300",
    description: "Advanced web navigation tool with AI-powered features",
  },
  {
    id: 2,
    name: "Site Mapper Elite",
    price: "$149",
    rating: 4.9,
    reviews: 89,
    category: "Tools",
    image: "/placeholder.svg?height=200&width=300",
    description: "Comprehensive website mapping and analysis solution",
  },
  {
    id: 3,
    name: "Navigation Analytics",
    price: "$79",
    rating: 4.7,
    reviews: 156,
    category: "Analytics",
    image: "/placeholder.svg?height=200&width=300",
    description: "Deep insights into user navigation patterns",
  },
  {
    id: 4,
    name: "Mobile Navigator",
    price: "$59",
    rating: 4.6,
    reviews: 203,
    category: "Mobile",
    image: "/placeholder.svg?height=200&width=300",
    description: "Optimized navigation tools for mobile devices",
  },
  {
    id: 5,
    name: "Enterprise Suite",
    price: "$299",
    rating: 4.9,
    reviews: 67,
    category: "Enterprise",
    image: "/placeholder.svg?height=200&width=300",
    description: "Complete navigation solution for large organizations",
  },
  {
    id: 6,
    name: "Developer Tools",
    price: "$129",
    rating: 4.8,
    reviews: 91,
    category: "Development",
    image: "/placeholder.svg?height=200&width=300",
    description: "Advanced tools for developers and technical teams",
  },
]

export default function ProductsPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>Products</span>
        </nav>

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Products</h1>
          <p className="text-lg text-gray-600">Discover our comprehensive suite of navigation and web analysis tools</p>
        </div>

        {/* Filter Buttons */}
        <div className="mb-8 flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            All Products
          </Button>
          <Button variant="outline" size="sm">
            Software
          </Button>
          <Button variant="outline" size="sm">
            Tools
          </Button>
          <Button variant="outline" size="sm">
            Analytics
          </Button>
          <Button variant="outline" size="sm">
            Mobile
          </Button>
          <Button variant="outline" size="sm">
            Enterprise
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <Badge className="absolute top-2 right-2">{product.category}</Badge>
              </div>

              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{product.name}</CardTitle>
                  <span className="text-xl font-bold text-blue-600">{product.price}</span>
                </div>
                <CardDescription>{product.description}</CardDescription>
              </CardHeader>

              <CardContent>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="ml-1 text-sm font-medium">{product.rating}</span>
                  </div>
                  <span className="text-sm text-gray-500">({product.reviews} reviews)</span>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" className="flex-1" asChild>
                    <Link href={`/products/${product.id}`}>
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Link>
                  </Button>
                  <Button size="sm" variant="outline">
                    <ShoppingCart className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <section className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Need Help Choosing?</h2>
          <p className="text-gray-600 mb-6">Our experts can help you find the perfect solution for your needs</p>
          <div className="flex gap-4 justify-center">
            <Button asChild>
              <Link href="/contact">Get Consultation</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/pricing">View Pricing</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
