import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Calendar, Users } from "lucide-react"
import Link from "next/link"

const portfolioItems = [
  {
    id: 1,
    title: "E-commerce Navigation Redesign",
    client: "TechStore Inc.",
    category: "E-commerce",
    description:
      "Complete navigation overhaul for a major online retailer, resulting in 40% increase in conversion rates.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["React", "Next.js", "Analytics", "A/B Testing"],
    results: ["40% increase in conversions", "25% reduction in bounce rate", "60% improvement in mobile navigation"],
    date: "2024-01-15",
    duration: "3 months",
    teamSize: 5,
    link: "#",
  },
  {
    id: 2,
    title: "SaaS Platform Navigation Optimization",
    client: "CloudTech Solutions",
    category: "SaaS",
    description: "Streamlined complex navigation for a B2B SaaS platform, improving user onboarding by 50%.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["Vue.js", "TypeScript", "User Testing", "Heatmaps"],
    results: ["50% faster user onboarding", "35% increase in feature adoption", "20% reduction in support tickets"],
    date: "2023-12-10",
    duration: "4 months",
    teamSize: 4,
    link: "#",
  },
  {
    id: 3,
    title: "Mobile App Navigation Study",
    client: "FinanceApp Pro",
    category: "Mobile",
    description: "Comprehensive mobile navigation analysis and optimization for a financial services app.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["React Native", "Mobile Analytics", "User Research", "Prototyping"],
    results: ["45% increase in daily active users", "30% improvement in task completion", "4.8/5 app store rating"],
    date: "2023-11-20",
    duration: "2 months",
    teamSize: 3,
    link: "#",
  },
  {
    id: 4,
    title: "Educational Platform Navigation",
    client: "LearnOnline University",
    category: "Education",
    description: "Redesigned navigation for online learning platform serving 50,000+ students.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["Angular", "Accessibility Tools", "Learning Analytics", "Progressive Web App"],
    results: ["60% increase in course completion", "WCAG 2.1 AA compliance", "25% reduction in navigation time"],
    date: "2023-10-05",
    duration: "5 months",
    teamSize: 6,
    link: "#",
  },
  {
    id: 5,
    title: "Healthcare Portal Navigation",
    client: "MedConnect Systems",
    category: "Healthcare",
    description: "Secure and intuitive navigation design for patient portal and healthcare provider dashboard.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["React", "HIPAA Compliance", "Security Testing", "Multi-role Navigation"],
    results: ["70% increase in patient engagement", "HIPAA compliant design", "99.9% uptime achieved"],
    date: "2023-09-15",
    duration: "6 months",
    teamSize: 8,
    link: "#",
  },
  {
    id: 6,
    title: "News Website Navigation Audit",
    client: "Global News Network",
    category: "Media",
    description: "Performance optimization and navigation restructuring for high-traffic news website.",
    image: "/placeholder.svg?height=300&width=400",
    technologies: ["WordPress", "CDN Optimization", "SEO", "Performance Monitoring"],
    results: ["50% faster page load times", "35% increase in page views", "Improved SEO rankings"],
    date: "2023-08-30",
    duration: "3 months",
    teamSize: 4,
    link: "#",
  },
]

const categories = ["All", "E-commerce", "SaaS", "Mobile", "Education", "Healthcare", "Media"]

export default function PortfolioPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>Portfolio</span>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Portfolio</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our successful navigation optimization projects across various industries. See how we've helped
            businesses improve their user experience and achieve measurable results.
          </p>
        </div>

        {/* Filter Categories */}
        <div className="mb-8 flex flex-wrap gap-2 justify-center">
          {categories.map((category) => (
            <Button key={category} variant="outline" size="sm">
              {category}
            </Button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {portfolioItems.map((item) => (
            <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img src={item.image || "/placeholder.svg"} alt={item.title} className="w-full h-48 object-cover" />
                <Badge className="absolute top-4 left-4">{item.category}</Badge>
              </div>

              <CardHeader>
                <CardTitle className="text-lg">{item.title}</CardTitle>
                <CardDescription className="text-blue-600 font-medium">{item.client}</CardDescription>
                <p className="text-sm text-gray-600">{item.description}</p>
              </CardHeader>

              <CardContent>
                {/* Project Details */}
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {item.duration}
                  </div>
                  <div className="flex items-center">
                    <Users className="h-3 w-3 mr-1" />
                    {item.teamSize} people
                  </div>
                </div>

                {/* Technologies */}
                <div className="mb-4">
                  <p className="text-sm font-medium mb-2">Technologies:</p>
                  <div className="flex flex-wrap gap-1">
                    {item.technologies.map((tech, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Key Results */}
                <div className="mb-4">
                  <p className="text-sm font-medium mb-2">Key Results:</p>
                  <ul className="text-xs text-gray-600 space-y-1">
                    {item.results.slice(0, 2).map((result, index) => (
                      <li key={index} className="flex items-center">
                        <span className="w-1 h-1 bg-green-600 rounded-full mr-2"></span>
                        {result}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href={`/portfolio/${item.id}`}>
                    View Case Study
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Section */}
        <section className="mb-12">
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <Card>
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">50+</div>
                <p className="text-gray-600">Projects Completed</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-green-600 mb-2">98%</div>
                <p className="text-gray-600">Client Satisfaction</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-purple-600 mb-2">45%</div>
                <p className="text-gray-600">Avg. Conversion Increase</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-orange-600 mb-2">6</div>
                <p className="text-gray-600">Industries Served</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Ready to Start Your Project?</h2>
          <p className="text-gray-600 mb-6">
            Let's discuss how we can help optimize your website's navigation and improve user experience
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Start Your Project</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/services">View Our Services</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
