import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, X } from "lucide-react"
import Link from "next/link"

const pricingPlans = [
  {
    name: "Starter",
    price: "$29",
    period: "/month",
    description: "Perfect for small websites and personal projects",
    features: [
      "Up to 5 pages analysis",
      "Basic navigation testing",
      "Email support",
      "Monthly reports",
      "1 user account",
    ],
    notIncluded: ["Advanced analytics", "API access", "Custom integrations", "Priority support"],
    popular: false,
    cta: "Start Free Trial",
  },
  {
    name: "Professional",
    price: "$99",
    period: "/month",
    description: "Ideal for growing businesses and agencies",
    features: [
      "Up to 50 pages analysis",
      "Advanced navigation testing",
      "Priority email & chat support",
      "Weekly reports",
      "5 user accounts",
      "Advanced analytics",
      "API access",
      "Custom integrations",
    ],
    notIncluded: ["White-label reports", "Dedicated account manager"],
    popular: true,
    cta: "Start Free Trial",
  },
  {
    name: "Enterprise",
    price: "$299",
    period: "/month",
    description: "For large organizations with complex needs",
    features: [
      "Unlimited pages analysis",
      "Enterprise navigation testing",
      "24/7 phone & chat support",
      "Daily reports",
      "Unlimited user accounts",
      "Advanced analytics",
      "Full API access",
      "Custom integrations",
      "White-label reports",
      "Dedicated account manager",
      "Custom training",
      "SLA guarantee",
    ],
    notIncluded: [],
    popular: false,
    cta: "Contact Sales",
  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>Pricing</span>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose the perfect plan for your navigation testing needs. All plans include a 14-day free trial with no
            credit card required.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {pricingPlans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.popular ? "border-blue-500 shadow-lg scale-105" : ""}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">Most Popular</Badge>
              )}

              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-600">{plan.period}</span>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>

              <CardContent>
                <Button
                  className={`w-full mb-6 ${plan.popular ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                  variant={plan.popular ? "default" : "outline"}
                  asChild
                >
                  <Link href="/contact">{plan.cta}</Link>
                </Button>

                <div className="space-y-3">
                  <p className="font-semibold text-sm">What's included:</p>
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-600" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}

                  {plan.notIncluded.length > 0 && (
                    <>
                      <p className="font-semibold text-sm mt-4 text-gray-600">Not included:</p>
                      {plan.notIncluded.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <X className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600">{feature}</span>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                question: "Can I change plans anytime?",
                answer: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.",
              },
              {
                question: "Is there a free trial?",
                answer: "All plans come with a 14-day free trial. No credit card required to get started.",
              },
              {
                question: "What payment methods do you accept?",
                answer: "We accept all major credit cards, PayPal, and bank transfers for enterprise plans.",
              },
              {
                question: "Can I cancel anytime?",
                answer:
                  "Yes, you can cancel your subscription at any time. No long-term contracts or cancellation fees.",
              },
            ].map((faq, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center bg-blue-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 mb-6">Join thousands of businesses that trust our navigation testing tools</p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Start Free Trial</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contact">Contact Sales</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
