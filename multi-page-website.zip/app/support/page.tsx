import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  MessageCircle,
  Mail,
  Phone,
  Book,
  Video,
  Download,
  Search,
  Clock,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import Link from "next/link"

const supportChannels = [
  {
    icon: MessageCircle,
    title: "Live Chat",
    description: "Get instant help from our support team",
    availability: "24/7",
    responseTime: "< 2 minutes",
    action: "Start Chat",
    href: "#",
  },
  {
    icon: Mail,
    title: "Email Support",
    description: "Send us detailed questions via email",
    availability: "24/7",
    responseTime: "< 4 hours",
    action: "Send Email",
    href: "mailto:support@navtest.com",
  },
  {
    icon: Phone,
    title: "Phone Support",
    description: "Speak directly with our experts",
    availability: "Mon-Fri 9AM-6PM PST",
    responseTime: "Immediate",
    action: "Call Now",
    href: "tel:+15551234567",
  },
]

const resources = [
  {
    icon: Book,
    title: "Documentation",
    description: "Comprehensive guides and API references",
    items: ["Getting Started Guide", "API Documentation", "Best Practices", "Troubleshooting"],
    href: "/docs",
  },
  {
    icon: Video,
    title: "Video Tutorials",
    description: "Step-by-step video guides",
    items: ["Platform Overview", "Advanced Features", "Integration Tutorials", "Webinar Recordings"],
    href: "/tutorials",
  },
  {
    icon: Download,
    title: "Downloads",
    description: "Tools, templates, and resources",
    items: ["Browser Extensions", "Mobile Apps", "Templates", "Code Examples"],
    href: "/downloads",
  },
]

const systemStatus = [
  { service: "Web Platform", status: "operational", uptime: "99.9%" },
  { service: "API Services", status: "operational", uptime: "99.8%" },
  { service: "Mobile Apps", status: "operational", uptime: "99.7%" },
  { service: "Analytics Engine", status: "maintenance", uptime: "99.5%" },
]

export default function SupportPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>Support</span>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Help & Support</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Get the help you need to make the most of our navigation testing platform. Our support team and resources
            are here to assist you.
          </p>
        </div>

        {/* Search Help */}
        <div className="mb-12">
          <Card>
            <CardContent className="pt-6">
              <div className="relative max-w-2xl mx-auto">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  placeholder="Search for help articles, guides, or common issues..."
                  className="pl-12 h-12 text-lg"
                />
              </div>
              <div className="flex flex-wrap gap-2 justify-center mt-4">
                <Badge variant="outline">Getting Started</Badge>
                <Badge variant="outline">API Integration</Badge>
                <Badge variant="outline">Billing Issues</Badge>
                <Badge variant="outline">Navigation Testing</Badge>
                <Badge variant="outline">Mobile Optimization</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Support Channels */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">Contact Support</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {supportChannels.map((channel, index) => {
              const IconComponent = channel.icon
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <IconComponent className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                    <CardTitle>{channel.title}</CardTitle>
                    <CardDescription>{channel.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-6 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Availability:</span>
                        <span className="font-medium">{channel.availability}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Response Time:</span>
                        <span className="font-medium">{channel.responseTime}</span>
                      </div>
                    </div>
                    <Button className="w-full" asChild>
                      <Link href={channel.href}>{channel.action}</Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>

        {/* Self-Service Resources */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">Self-Service Resources</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {resources.map((resource, index) => {
              const IconComponent = resource.icon
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <IconComponent className="h-8 w-8 text-blue-600 mb-2" />
                    <CardTitle>{resource.title}</CardTitle>
                    <CardDescription>{resource.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {resource.items.map((item, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center">
                          <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                          {item}
                        </li>
                      ))}
                    </ul>
                    <Button variant="outline" className="w-full bg-transparent" asChild>
                      <Link href={resource.href}>Explore {resource.title}</Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>

        {/* System Status */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">System Status</h2>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                All Systems Operational
              </CardTitle>
              <CardDescription>Last updated: {new Date().toLocaleString()}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemStatus.map((service, index) => (
                  <div key={index} className="flex items-center justify-between py-2 border-b last:border-b-0">
                    <div className="flex items-center gap-3">
                      {service.status === "operational" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertCircle className="h-4 w-4 text-yellow-600" />
                      )}
                      <span className="font-medium">{service.service}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge
                        variant={service.status === "operational" ? "default" : "secondary"}
                        className={service.status === "operational" ? "bg-green-600" : "bg-yellow-600"}
                      >
                        {service.status === "operational" ? "Operational" : "Maintenance"}
                      </Badge>
                      <span className="text-sm text-gray-600">{service.uptime} uptime</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/status">View Full Status Page</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Popular Help Articles */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">Popular Help Articles</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {[
              "How to set up your first navigation test",
              "Understanding navigation analytics reports",
              "Integrating with third-party tools",
              "Troubleshooting common issues",
              "Best practices for mobile navigation testing",
              "Setting up team collaboration",
              "Configuring alerts and notifications",
              "Exporting data and reports",
            ].map((article, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{article}</span>
                    <Clock className="h-4 w-4 text-gray-400" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Contact CTA */}
        <section className="text-center bg-blue-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Still Need Help?</h2>
          <p className="text-gray-600 mb-6">Our support team is standing by to help you succeed with our platform</p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Contact Support</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/faq">Browse FAQ</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
