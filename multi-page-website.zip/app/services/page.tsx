import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Search, BarChart3, Shield, Smartphone, Globe } from "lucide-react"
import Link from "next/link"

const services = [
  {
    icon: Code,
    title: "Web Development",
    description: "Custom website development with modern technologies and best practices",
    features: ["Responsive Design", "SEO Optimization", "Performance Tuning", "Cross-browser Testing"],
    price: "Starting at $2,999",
    category: "Development",
  },
  {
    icon: Search,
    title: "SEO Optimization",
    description: "Comprehensive search engine optimization to improve your online visibility",
    features: ["Keyword Research", "On-page SEO", "Technical SEO", "Content Strategy"],
    price: "Starting at $899/month",
    category: "Marketing",
  },
  {
    icon: BarChart3,
    title: "Analytics & Reporting",
    description: "Advanced web analytics and performance monitoring solutions",
    features: ["Custom Dashboards", "Real-time Monitoring", "Conversion Tracking", "A/B Testing"],
    price: "Starting at $499/month",
    category: "Analytics",
  },
  {
    icon: Shield,
    title: "Security Audits",
    description: "Comprehensive security assessments and vulnerability testing",
    features: ["Security Scanning", "Penetration Testing", "Compliance Checks", "Risk Assessment"],
    price: "Starting at $1,499",
    category: "Security",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimization",
    description: "Mobile-first design and optimization for all devices",
    features: ["Responsive Design", "Mobile Performance", "Touch Optimization", "App Integration"],
    price: "Starting at $1,299",
    category: "Mobile",
  },
  {
    icon: Globe,
    title: "Global CDN Setup",
    description: "Content delivery network setup for worldwide performance",
    features: ["Global Distribution", "Edge Caching", "SSL Certificates", "Performance Monitoring"],
    price: "Starting at $299/month",
    category: "Infrastructure",
  },
]

export default function ServicesPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span>Services</span>
        </nav>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Services</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Comprehensive web solutions to help your business succeed online. From development to optimization, we've
            got you covered.
          </p>
        </div>

        {/* Service Categories */}
        <div className="mb-8 flex flex-wrap gap-2 justify-center">
          <Button variant="outline" size="sm">
            All Services
          </Button>
          <Button variant="outline" size="sm">
            Development
          </Button>
          <Button variant="outline" size="sm">
            Marketing
          </Button>
          <Button variant="outline" size="sm">
            Analytics
          </Button>
          <Button variant="outline" size="sm">
            Security
          </Button>
          <Button variant="outline" size="sm">
            Mobile
          </Button>
          <Button variant="outline" size="sm">
            Infrastructure
          </Button>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service, index) => {
            const IconComponent = service.icon
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow h-full">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <IconComponent className="h-12 w-12 text-blue-600" />
                    <Badge variant="secondary">{service.category}</Badge>
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>

                <CardContent className="flex-1 flex flex-col">
                  <div className="mb-6">
                    <h4 className="font-semibold mb-3">What's Included:</h4>
                    <ul className="space-y-1">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center">
                          <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-auto">
                    <div className="text-lg font-bold text-blue-600 mb-4">{service.price}</div>
                    <div className="flex gap-2">
                      <Button className="flex-1" asChild>
                        <Link href={`/services/${index + 1}`}>Learn More</Link>
                      </Button>
                      <Button variant="outline" asChild>
                        <Link href="/contact">Get Quote</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Process Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Our Process</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Discovery", description: "We analyze your needs and goals" },
              { step: "2", title: "Planning", description: "Create a detailed project roadmap" },
              { step: "3", title: "Execution", description: "Implement solutions with precision" },
              { step: "4", title: "Optimization", description: "Continuous improvement and support" },
            ].map((phase, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  {phase.step}
                </div>
                <h3 className="font-semibold text-lg mb-2">{phase.title}</h3>
                <p className="text-gray-600 text-sm">{phase.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 mb-6">Let's discuss your project and find the perfect solution for your needs</p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contact">Start Your Project</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/portfolio">View Our Work</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}
