import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Globe, Shield, Zap } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold mb-6 text-gray-900">Welcome to Navigator Test Site</h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            A comprehensive multi-page website designed to test your global web navigator. Explore various page types,
            navigation patterns, and interactive elements.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button asChild size="lg">
              <Link href="/about">
                Learn More <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/products">View Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Test Navigation Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Globe className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Multi-Level Navigation</CardTitle>
                <CardDescription>Test nested menus, breadcrumbs, and complex navigation structures</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" asChild className="w-full bg-transparent">
                  <Link href="/services">Explore Services</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Zap className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Dynamic Content</CardTitle>
                <CardDescription>Interactive forms, search functionality, and dynamic page updates</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" asChild className="w-full bg-transparent">
                  <Link href="/blog">Read Blog</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>User Interactions</CardTitle>
                <CardDescription>Login forms, contact pages, and user-generated content areas</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" asChild className="w-full bg-transparent">
                  <Link href="/contact">Get in Touch</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Quick Navigation Test</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" asChild className="h-16 bg-transparent">
              <Link href="/portfolio">Portfolio</Link>
            </Button>
            <Button variant="outline" asChild className="h-16 bg-transparent">
              <Link href="/pricing">Pricing</Link>
            </Button>
            <Button variant="outline" asChild className="h-16 bg-transparent">
              <Link href="/faq">FAQ</Link>
            </Button>
            <Button variant="outline" asChild className="h-16 bg-transparent">
              <Link href="/support">Support</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
