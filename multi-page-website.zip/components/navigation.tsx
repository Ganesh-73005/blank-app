"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { Menu, Globe } from "lucide-react"
import { cn } from "@/lib/utils"

const mainNavItems = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  {
    label: "Products",
    href: "/products",
    children: [
      { href: "/products", label: "All Products" },
      { href: "/products/1", label: "Web Navigator Pro" },
      { href: "/products/2", label: "Site Mapper Elite" },
      { href: "/products/3", label: "Navigation Analytics" },
    ],
  },
  {
    label: "Services",
    href: "/services",
    children: [
      { href: "/services", label: "All Services" },
      { href: "/services/1", label: "Web Development" },
      { href: "/services/2", label: "SEO Optimization" },
      { href: "/services/3", label: "Analytics & Reporting" },
    ],
  },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
]

const additionalPages = [
  { href: "/portfolio", label: "Portfolio" },
  { href: "/pricing", label: "Pricing" },
  { href: "/faq", label: "FAQ" },
  { href: "/support", label: "Support" },
]

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2">
          <Globe className="h-6 w-6 text-blue-600" />
          <span className="font-bold text-xl">NavTest</span>
        </Link>

        {/* Desktop Navigation */}
        <NavigationMenu className="hidden lg:flex">
          <NavigationMenuList>
            {mainNavItems.map((item) => (
              <NavigationMenuItem key={item.label}>
                {item.children ? (
                  <>
                    <NavigationMenuTrigger className="h-10">{item.label}</NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <div className="grid w-[400px] gap-3 p-4">
                        {item.children.map((child) => (
                          <NavigationMenuLink key={child.href} asChild>
                            <Link
                              href={child.href}
                              className={cn(
                                "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                                pathname === child.href && "bg-accent",
                              )}
                            >
                              <div className="text-sm font-medium leading-none">{child.label}</div>
                            </Link>
                          </NavigationMenuLink>
                        ))}
                      </div>
                    </NavigationMenuContent>
                  </>
                ) : (
                  <NavigationMenuLink asChild>
                    <Link
                      href={item.href}
                      className={cn(
                        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50",
                        pathname === item.href && "bg-accent",
                      )}
                    >
                      {item.label}
                    </Link>
                  </NavigationMenuLink>
                )}
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center space-x-2">
          <Button variant="outline" asChild>
            <Link href="/pricing">Pricing</Link>
          </Button>
          <Button asChild>
            <Link href="/contact">Get Started</Link>
          </Button>
        </div>

        {/* Mobile Navigation */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="lg:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <div className="flex flex-col space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <Link href="/" className="flex items-center space-x-2" onClick={() => setIsOpen(false)}>
                  <Globe className="h-6 w-6 text-blue-600" />
                  <span className="font-bold text-xl">NavTest</span>
                </Link>
              </div>

              <nav className="flex flex-col space-y-2">
                {mainNavItems.map((item) => (
                  <div key={item.label}>
                    <Link
                      href={item.href}
                      className={cn(
                        "block px-3 py-2 rounded-md text-sm font-medium hover:bg-accent",
                        pathname === item.href && "bg-accent",
                      )}
                      onClick={() => setIsOpen(false)}
                    >
                      {item.label}
                    </Link>
                    {item.children && (
                      <div className="ml-4 mt-2 space-y-1">
                        {item.children.map((child) => (
                          <Link
                            key={child.href}
                            href={child.href}
                            className={cn(
                              "block px-3 py-1 rounded-md text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                              pathname === child.href && "bg-accent text-accent-foreground",
                            )}
                            onClick={() => setIsOpen(false)}
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                <div className="border-t pt-4 mt-4">
                  <p className="px-3 text-sm font-medium text-muted-foreground mb-2">More Pages</p>
                  {additionalPages.map((page) => (
                    <Link
                      key={page.href}
                      href={page.href}
                      className={cn(
                        "block px-3 py-2 rounded-md text-sm hover:bg-accent",
                        pathname === page.href && "bg-accent",
                      )}
                      onClick={() => setIsOpen(false)}
                    >
                      {page.label}
                    </Link>
                  ))}
                </div>
              </nav>

              <div className="border-t pt-4 space-y-2">
                <Button className="w-full" asChild>
                  <Link href="/contact" onClick={() => setIsOpen(false)}>
                    Get Started
                  </Link>
                </Button>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/pricing" onClick={() => setIsOpen(false)}>
                    View Pricing
                  </Link>
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
