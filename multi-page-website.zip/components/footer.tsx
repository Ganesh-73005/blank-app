import Link from "next/link"
import { Globe, Mail, Phone, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const footerLinks = {
  Company: [
    { href: "/about", label: "About Us" },
    { href: "/blog", label: "Blog" },
    { href: "/contact", label: "Contact" },
    { href: "/careers", label: "Careers" },
  ],
  Products: [
    { href: "/products", label: "All Products" },
    { href: "/products/1", label: "Web Navigator Pro" },
    { href: "/products/2", label: "Site Mapper Elite" },
    { href: "/pricing", label: "Pricing" },
  ],
  Services: [
    { href: "/services", label: "All Services" },
    { href: "/services/1", label: "Web Development" },
    { href: "/services/2", label: "SEO Optimization" },
    { href: "/support", label: "Support" },
  ],
  Resources: [
    { href: "/faq", label: "FAQ" },
    { href: "/portfolio", label: "Portfolio" },
    { href: "/documentation", label: "Documentation" },
    { href: "/api", label: "API Reference" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <Globe className="h-6 w-6 text-blue-600" />
              <span className="font-bold text-xl">NavTest</span>
            </Link>
            <p className="text-gray-600 mb-6 max-w-md">
              A comprehensive multi-page website designed to test your global web navigator. Explore various page types,
              navigation patterns, and interactive elements.
            </p>

            {/* Contact Info */}
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>hello@navtest.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>San Francisco, CA</span>
              </div>
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-semibold text-gray-900 mb-4">{category}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-gray-600 hover:text-blue-600 text-sm transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="border-t mt-12 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Stay Updated</h3>
              <p className="text-gray-600 text-sm">Subscribe to our newsletter for the latest updates and insights.</p>
            </div>
            <div className="flex gap-2 w-full md:w-auto">
              <Input placeholder="Enter your email" className="md:w-64" />
              <Button>Subscribe</Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-sm">© {new Date().getFullYear()} NavTest. All rights reserved.</p>
          <div className="flex gap-6 text-sm">
            <Link href="/privacy" className="text-gray-600 hover:text-blue-600">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-gray-600 hover:text-blue-600">
              Terms of Service
            </Link>
            <Link href="/cookies" className="text-gray-600 hover:text-blue-600">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
